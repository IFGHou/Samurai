function do_main(){
	window.status="STATUSBARSTRING";
	return_result(result_id, "Status updated");	
}

do_main();