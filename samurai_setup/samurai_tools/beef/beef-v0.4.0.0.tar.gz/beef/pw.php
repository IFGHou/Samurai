<?
$passwd = 'BeEFConfigPass';
?>
