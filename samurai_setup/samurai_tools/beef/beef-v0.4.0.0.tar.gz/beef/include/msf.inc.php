<?php
define('MSF_HOST', '127.0.0.1');
define('MSF_PORT', '55553');
define('MSF_USER', 'msf');
define('MSF_PASS', 'BeEFMSFPass');
define('MSF_BASE_URL', 'http://192.168.1.235');
?>
